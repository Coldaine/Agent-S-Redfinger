from __future__ import annotations
import base64, os, json, time
from typing import Optional, Dict, Any

"""
Vision providers stub.
You will implement the HTTP calls using the prompt in prompts/full_bootstrap_prompt.txt.

API:
    analyze_image(image_bytes: bytes, provider: str, model: str) -> str
Returns: provider text (expected to contain STRICT JSON with normalized coords).
"""

def b64_png(image_bytes: bytes) -> str:
    return "data:image/png;base64," + base64.b64encode(image_bytes).decode("ascii")

def analyze_image(image_bytes: bytes, provider: str, model: str) -> str:
    provider = (provider or "none").lower()
    if provider == "none":
        # Return a center prediction in strict JSON for smoke tests.
        return json.dumps({"coords":{"space":"normalized","x":0.5,"y":0.5},"why":"center","confidence":0.1}})
    # TODO: Implement OpenAI GPT-5 Vision and Zhipu GLM-4.5V here using the big prompt.
    raise NotImplementedError(f"Provider '{provider}' not implemented yet")
